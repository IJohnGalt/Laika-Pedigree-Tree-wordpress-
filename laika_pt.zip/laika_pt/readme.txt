=== Laika Pedigree Tree ===
Contributors: burria
Tags: pedigree, tree, family, pets, laika, dog
Requires at least: 3.0.1
Tested up to: 3.7.9
License: GPLv2
Stable tag: 0.1
License URI: http://www.gnu.org/licenses/gpl-2.0.html




== Description ==

Creates a custom content type to upload pets, 
let you select the mother and father of every pet and then draws a pedigree 
tree when the user is viewing the post.  

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Use the Settings->Laika_Configuration to configure the plugin
4. Copy "laika_pt_theme.php" to your theme directory to modify how the content will be displayed. 


